const { ObjectId } = require("mongodb")
const { getMongoCollection } = require("./mongodb")

const DB_Name = "Exerc_Rafael_A"
const COLLECTION_NAME = "colecao"


async function getColById(id){
    const collection = await getMongoCollection(DB_Name, COLLECTION_NAME)
    return await collection.findOne({ _id: new ObjectId(id)})
}

async function checkColById(id){
    const collection = await getMongoCollection(DB_Name, COLLECTION_NAME)
    return await collection.findOne({ id: id})
}


async function updateColById(id, col){
    const collection = await getMongoCollection(DB_Name, COLLECTION_NAME)
    return await collection.updateOne({ _id: new ObjectId(id)}, { $set: {...col }})
}


async function insertCol(col){
    const collection = await getMongoCollection(DB_Name, COLLECTION_NAME)
    return await collection.insertOne(col)
}


module.exports = {
    getColById,
    updateColById,
    insertCol,
    checkColById   
}


