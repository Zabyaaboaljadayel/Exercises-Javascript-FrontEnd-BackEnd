const { insertCol, updateColById, getColById, checkColById } = require("../data/paperWork");

async function createCol(col){
    const cole = await insertCol(col)
    return cole.insertedId
}
async function changeColById(id, col){
    const colee = await updateColById(id, col)
    return colee
}
async function findColById(id){
    const coleee = await getColById(id)
    return coleee
}
async function seeColById(id){
    const coleee = await checkColById(id)
    return coleee
}


module.exports = {
    createCol,
    changeColById,
    findColById,
    seeColById
}