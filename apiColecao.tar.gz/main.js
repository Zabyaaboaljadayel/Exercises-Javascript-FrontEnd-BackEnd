const { ObjectId } = require('mongodb')
const express = require('express')
const { createCol, changeColById, findColById, seeColById } = require('./services/paperWork')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())

app.get("/api/colecao/:id", async (req, res) => {
    if (!ObjectId.isValid(req.params.id)) {
        return res.sendStatus(404)
    }
    const id = (req.params.id)

    const cole = await findColById(id)
    if (cole) {
        return res.status(200).json(cole)
    } else {
        return res.sendStatus(404)
    }
})

app.patch("/api/colecao/:id", async (req, res) => {
    if (!ObjectId.isValid(req.params.id)) {
        return res.sendStatus(404)
    }
    const cole = await changeColById(req.params.id, req.body)
    if (cole) {
        return res.sendStatus(200)
    } else {
        return res.sendStatus(404)
    }
})


app.post("/api/colecao", async (req, res) => {

    const ele = await seeColById(req.body.id)

    if (!ele) {
        const _id = await createCol(req.body)
        return res.status(201).json({ _id })
    } else {
        return res.sendStatus(409)
    }


})


app.listen(port, () => {
    console.log(`À escuta em http://localhost:${port}`)
})