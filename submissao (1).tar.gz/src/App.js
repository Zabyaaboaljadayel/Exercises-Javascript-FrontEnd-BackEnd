import logo from './logo.svg';
import './App.css';
import  Lista  from './ListaComApagar';
function App() {
  return (
    <div className="App">
      <Lista
        itens={
          [
            { name: "Macbook", price: 23000 },
            { name: "Surface", price: 1530 },
            { name: "Omen", price: 999 },
            { name: "Legion", price: 1530 },
            { name: "Pavilion", price: 230 },
        ]
        }
      />
    </div>
  );
}

export default App;