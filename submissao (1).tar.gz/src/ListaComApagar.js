import { useState } from "react"

/*

Cria um Componente React ListaComApagar, que recebe a prop itens, que é um array de objetos:

O componente ListaComApagar deve:

    Guardar a prop itens no state.

    Mapear o state de forma a que cada item mapeado renderize:

        Uma div com a key com o valor da propriedade key de cada item. :

            Um título de nível 3 com o valor da propriedade name de cada item.

            Um parágrafo com o formato de preço € onde preço é a propriedade price de cada item.

            Um botão que quando clicado deve remover o item da lista do state


*/


export default function Lista({itens}) {
    const [state, setState] = useState(itens)
    const deleteElement = (index) => {
        setState((prevState) => {
            console.log(index)
            console.log(prevState.slice(0, index).concat(prevState.slice(index + 1)))
            return prevState.slice(0, index).concat(prevState.slice(index + 1))
        })
    }
    return (
        <div>
            {state.map((e, i) => (<div key={e.name}>
                <h3
                onClick={() => console.log(e.price + "€")}>
                {e.name}
                </h3>
                <p >{e.price} €</p>
                <button onClick={() => deleteElement(i)}>Apagar</button>
                </div>))}
        </div>
    )

}