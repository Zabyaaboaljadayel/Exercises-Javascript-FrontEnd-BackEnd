const pessoas = [
    "Maria",
    "José",
    "Pedro"
]
const pessoas2 = [
    "Maria",
    "José",
    "Pedro"
]


export default pessoas
export {pessoas2}