
export function PaginaPrincipal(){
    return(
        <div className='container'>
            
            <div></div>
            <div></div>
        </div>
    )
}