// db.js
const { MongoClient } = require('mongodb')
const URL = process.env.MONGO_URL ?? "mongodb://localhost:27017"

const DB_NAME = "desafioBackEnd"
const COLLECTION_NAME = "desafioBackEnd"

async function createDocument(data) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const result = await collection.insertOne(data)
    return result.insertedId
}

createDocument({
    sku: 'ABC',
    description: 'Sample Product',
    price: 100.00,
    stock: 20
})
    .then((id) => console.log("Documento 1 inserido com o id:", id))

createDocument({
    sku: 'BCD',
    description: 'Sample Product',
    price: 99.00,
    stock: 0
})
    .then((id) => console.log("Documento 2 inserido com o id:", id))
    
let client
async function connectToMongo() {
    try {
        if (!client) {
            client = await MongoClient.connect(URL)
        }
        return client;
    } catch (err) {
        console.log(err)
    }
}

async function getMongoCollection(dbName, collectionName) {
    const client = await connectToMongo()
    return client.db(dbName).collection(collectionName)
}

module.exports = { getMongoCollection }