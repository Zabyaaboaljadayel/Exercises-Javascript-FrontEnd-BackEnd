const { ObjectId } = require("mongodb")
const { generateToken } = require("../services/common")
const { getMongoCollection } = require("./mongodb")
const { getUserByEmail } = require("./users")

const DB_NAME = "Desafio"
const COLLECTION_NAME = "sessoes"

async function addSession(userId) {
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const token = await collection.insertOne({ userId })
    return token.insertedId
}

async function getSessionByToken(token) {
    if (!ObjectId.isValid(token)) return null
    const collection = await getMongoCollection(DB_NAME, COLLECTION_NAME)
    const resultado = await collection.findOne({ _id: new ObjectId(token) })
    return resultado
}

module.exports = {
    addSession,
    getSessionByToken
}