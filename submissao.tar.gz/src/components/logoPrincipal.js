export default function LogoPrincipal() {
  return (
    <div className="main">
      <div>
        <img className="logo" src="/img/logo.png" alt="logo" />
      </div>
      <div className="button1">
        <button className="log" type="submit">
          Login
        </button>
      </div>
    </div>
  );
}
