const express = require('express')
const app = express()
const port = process.env.PORT ?? 3000
app.use(express.json())


const colecao = []
app.get("/api/colecao/:id", (req, res) => {
    const id = Number(req.params.id)
    
    if (colecao.some(e => e.id === id)) {
        res.status(200).json(colecao.find(e => e.id === id)) 
    } else {
        res.sendStatus(404) 
    }
})

app.patch("/api/colecao/:id", (req, res) => {
    const id = Number(req.params.id)
    const index = colecao.findIndex(e => e.id === id)
    if(index === -1) return res.sendStatus(404)
    colecao[index] = req.body
    return res.sendStatus(200)
    
})


app.post("/api/colecao", (req, res) => {
    const id = Number(req.body.id)
    if(!colecao.some(e => e.id === id)){
        colecao.push(req.body)
        res.sendStatus(200)
    }else{
        res.sendStatus(409)
    }
})


app.listen(port, () => {
    console.log(`À escuta em http://localhost:${port}`)
  })