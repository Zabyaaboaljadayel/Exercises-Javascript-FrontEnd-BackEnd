const {Calculadora} = require("./calculator")
const express = require('express')
const app= express()
const calc= new Calculadora()
const PORT= process.env.PORT ?? 3001


app.use(express.json())
app.post('/op/potencia',(req, res)=>{
    const {a, b} = req.body
    if ( isNaN(Number(req.body.a)) || (b !== undefined && isNaN(Number(req.body.b )))){
        res.status(400).json({ erro: "Argumentos Inválidos"})
    }else{
        res.status(200).json({calculadora: calc.potencia(a, b)})
    }
})
app.post('/op/somar',(req, res)=>{
    const {a, b} = req.body
    if ( isNaN(Number(req.body.a)) || (b !== undefined && isNaN(Number(req.body.b )))){
        res.status(400).json({ erro: "Argumentos Inválidos"})
    }else{
        res.status(200).json({calculadora: calc.somar(a, b)})
    }
})
app.post('/op/subtrair',(req, res)=>{
    const {a, b} = req.body
    if ( isNaN(Number(req.body.a)) || (b !== undefined && isNaN(Number(req.body.b )))){
        res.status(400).json({ erro: "Argumentos Inválidos"})
    }else{
        res.status(200).json({calculadora: calc.subtrair(a, b)})
    }
})
app.post('/op/dividir',(req, res)=>{
    const {a, b} = req.body
    if ( isNaN(Number(req.body.a)) || (b !== undefined && isNaN(Number(req.body.b )))){
        res.status(400).json({ erro: "Argumentos Inválidos"})
    }else{
        res.status(200).json({calculadora: calc.dividir(a, b)})
    }
})
app.post('/op/multiplicar',(req, res)=>{
    const {a, b} = req.body
    if ( isNaN(Number(req.body.a)) || (b !== undefined && isNaN(Number(req.body.b )))){
        res.status(400).json({ erro: "Argumentos Inválidos"})
    }else{
        res.status(200).json({calculadora: calc.multiplicar(a, b)})
    }
})
app.delete('/',(req, res)=>{
        res.status(200).json({calculadora: calc.limparHistorico()})
})
app.post('/repetir',(req, res)=>{
    const {num} = req.body
        res.status(200).json({calculadora: calc.repetir(num).toJSON()})
})
app.get('/',(req, res)=>{
        res.status(200).json({calculadora: calc})
})
app.get('/ultimo-resultado',(req, res)=>{
        res.status(200).json({ultimoResultado: calc.obterResultado().toString()})
})


app.listen(PORT, ()=> {
    console.log('...')
})